// n8n notification queue worker. At-least-once delivery: n8n should de-duplicate on the lead_id field / x-lead-id header.
const MAX_ATTEMPTS = 8;
async function deliver(db: any, r: any, url: string): Promise<"sent" | "failed" | "skipped"> {
  const attempt = r.attempts + 1;
  const claim = await db.from("lead_notifications").update({ status: "sending", attempts: attempt, locked_at: new Date().toISOString() })
    .eq("id", r.id).eq("attempts", r.attempts).eq("status", r.status).select("id"); // optimistic lock
  if (claim.error || !claim.data?.length) return "skipped";
  const { data: l } = await db.from("leads").select("id,cafe_name,city,phone,contact_method,marketing_consent,created_at").eq("id", r.lead_id).maybeSingle();
  let ok = false, code: number | null = null, err: string | null = null;
  if (!l) err = "lead not found";
  else try {
    const res = await fetch(url, { method: "POST", signal: AbortSignal.timeout(5000),
      headers: { "content-type": "application/json", "x-webhook-secret": process.env.N8N_WEBHOOK_SECRET ?? "", "x-lead-id": l.id },
      body: JSON.stringify({ event: "new_lead", lead_id: l.id, ...l, id: undefined }) });
    code = res.status; ok = res.ok; if (!ok) err = "HTTP " + res.status;
  } catch (e: any) { err = String(e?.message ?? e).slice(0, 200); }
  await db.from("lead_notification_log").insert({ notification_id: r.id, attempt, ok, http_status: code, error: err });
  const patch = ok ? { status: "sent", sent_at: new Date().toISOString(), last_error: null }
    : { status: attempt >= MAX_ATTEMPTS ? "dead" : "failed", last_error: err, next_attempt_at: new Date(Date.now() + Math.min(2 ** attempt * 60, 21600) * 1000).toISOString() };
  await db.from("lead_notifications").update(patch).eq("id", r.id);
  return ok ? "sent" : "failed";
}
export async function processQueue(db: any, limit = 10) {
  const url = process.env.N8N_WEBHOOK_URL; if (!url) return { configured: false, sent: 0, failed: 0 };
  const now = new Date().toISOString(), stale = new Date(Date.now() - 10 * 60000).toISOString();
  const { data, error } = await db.from("lead_notifications").select("id,lead_id,attempts,status")
    .or(`and(status.in.(pending,failed),next_attempt_at.lte.${now}),and(status.eq.sending,locked_at.lt.${stale})`).order("created_at").limit(limit);
  if (error) return { configured: true, sent: 0, failed: 0, error: error.message };
  let sent = 0, failed = 0;
  for (const r of data ?? []) { const x = await deliver(db, r, url); if (x === "sent") sent++; else if (x === "failed") failed++; }
  return { configured: true, sent, failed };
}
