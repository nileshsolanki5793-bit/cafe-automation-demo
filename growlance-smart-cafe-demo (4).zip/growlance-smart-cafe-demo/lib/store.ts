"use client";
// SIMULATED LOCAL MODE: state lives in this browser (localStorage) and syncs only between tabs of the SAME browser
// via BroadcastChannel. It is NOT multi-device realtime. See lib/live.ts for the Supabase implementation.
import { useSyncExternalStore } from "react";
import { canMove } from "./transitions";
export type Line = { name: string; opt: string; price: number; q: number; id?: number; size?: number; ex?: number[] };
export type Fb = { food: number; service: number; amb: number };
export type Order = { id: any; no: number; key: string; table: string; items: Line[]; sub: number; total: number; status: string; paid: boolean; fb: Fb | null };
type S = { orders: Order[]; events: { name: string; t: number }[]; leads: any[] };
const EMPTY: S = { orders: [], events: [], leads: [] }, K = "gl-demo-local";
let st: S = EMPTY, loaded = false;
const subs = new Set<() => void>();
const bc = typeof window !== "undefined" && "BroadcastChannel" in window ? new BroadcastChannel(K) : null;
const emit = () => subs.forEach((f) => f());
function load() { try { st = JSON.parse(localStorage.getItem(K) || "") || EMPTY; } catch { st = EMPTY; } loaded = true; }
function save(n: S) { st = n; try { localStorage.setItem(K, JSON.stringify(n)); } catch {} bc?.postMessage(1); emit(); }
if (bc) bc.onmessage = () => { load(); emit(); };
function sub(f: () => void) { if (!loaded) load(); subs.add(f); return () => { subs.delete(f); }; }
export const useLocal = () => useSyncExternalStore(sub, () => st, () => EMPTY);
const ev = (name: string) => [...st.events, { name, t: Date.now() }];
const patch = (id: number, p: Partial<Order>, e?: string) =>
  save({ ...st, orders: st.orders.map((o) => (o.id === id ? { ...o, ...p } : o)), events: e ? ev(e) : st.events });
export const localA = {
  track: (name: string) => save({ ...st, events: ev(name) }),
  place(key: string, table: string, items: Line[]): number {
    const dup = st.orders.find((o) => o.key === key); if (dup) return dup.id; // duplicate-submit protection
    const sub = items.reduce((s, l) => s + l.price * l.q, 0);
    const o: Order = { id: 101 + st.orders.length, no: 101 + st.orders.length, key, table, items, sub, total: sub + Math.round(sub * 0.05), status: "placed", paid: false, fb: null };
    save({ ...st, orders: [o, ...st.orders], events: ev("order_placed") }); return o.id;
  },
  advance(id: number, to: string) {
    const o = st.orders.find((x) => x.id === id); if (!o || !canMove(o.status, to)) return false;
    patch(id, { status: to }, to === "confirmed" ? "order_confirmed" : undefined); return true;
  },
  pay: (id: number) => patch(id, { paid: true }, "demo_payment_completed"),
  feedback: (id: number, fb: Fb) => patch(id, { fb }, "feedback_submitted"),
  lead: (l: any) => save({ ...st, leads: [...st.leads, l], events: ev("lead_submitted") }),
};
