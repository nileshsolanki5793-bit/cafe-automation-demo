"use client";
// LIVE CONNECTED MODE. Auth: Supabase anonymous sign-in; server verifies the token; Realtime uses the same session so RLS decides delivery.
// "live" is reported ONLY when (a) initial data loaded and (b) the Realtime channel confirmed SUBSCRIBED.
import { useSyncExternalStore } from "react";
import { getSb } from "./browserClient";
import type { Order, Fb, Line } from "./store";
type Status = "connecting" | "live" | "reconnecting" | "error";
type S = { orders: Order[]; events: any[]; leads: any[]; status: Status; code: string };
const EMPTY: S = { orders: [], events: [], leads: [], status: "connecting", code: "" };
let st = EMPTY, ready: Promise<void> | null = null, dataOk: boolean | null = null, sock: "joining" | "ok" | "down" = "joining";
const subs = new Set<() => void>();
const calc = (): Status => (dataOk === false ? "error" : dataOk === null || (sock === "joining") ? "connecting" : sock === "ok" ? "live" : "reconnecting");
const upd = (p: Partial<S> = {}) => { st = { ...st, ...p, status: calc() }; subs.forEach((f) => f()); };
async function token() {
  const sb = getSb(), { data } = await sb.auth.getSession(); if (data.session) return data.session.access_token;
  const r = await sb.auth.signInAnonymously();
  if (r.error || !r.data.session) throw new Error("Anonymous sign-in failed. Enable Anonymous sign-ins in Supabase Auth.");
  return r.data.session.access_token;
}
async function api(path: string, body?: any) {
  let r: Response;
  try { r = await fetch(path, { method: body ? "POST" : "GET", headers: { "content-type": "application/json", authorization: "Bearer " + (await token()) }, body: body ? JSON.stringify(body) : undefined }); }
  catch (e: any) { throw new Error(e?.message?.includes("Anonymous") ? e.message : "Network error. Nothing was saved."); }
  const d = await r.json().catch(() => null);
  if (!d || typeof d !== "object") throw new Error(`Unexpected server response (${r.status})`);
  if (!r.ok) throw new Error(d.error || `Request failed (${r.status})`); return d;
}
async function refresh() {
  try { const d = await api("/api/state"); if (!Array.isArray(d.orders)) throw new Error("Bad state"); dataOk = true; upd({ orders: d.orders }); }
  catch { dataOk = false; upd(); }
}
function boot() {
  return (ready ??= (async () => {
    try {
      const s = await api("/api/session", {}); if (typeof s.code !== "string") throw new Error("Bad session"); upd({ code: s.code });
      await refresh();
      const ch = getSb().channel("cafe");
      ["orders", "payments", "feedback"].forEach((t) => ch.on("postgres_changes", { event: "*", schema: "public", table: t }, () => refresh()));
      ch.subscribe((s: string) => {
        if (s === "SUBSCRIBED") { sock = "ok"; refresh(); } // refresh also recovers anything missed while disconnected
        else if (s === "CHANNEL_ERROR" || s === "TIMED_OUT" || s === "CLOSED") { sock = "down"; upd(); } // supabase-js retries automatically
      });
      setInterval(refresh, 20000); document.addEventListener("visibilitychange", () => { if (!document.hidden) refresh(); });
    } catch { dataOk = false; upd(); }
  })());
}
const sub = (f: () => void) => { boot(); subs.add(f); return () => { subs.delete(f); }; };
export const useLive = () => useSyncExternalStore(sub, () => st, () => EMPTY);
// Actions THROW on failure; the UI shows success only after the server confirmed it.
const act = async (id: string, a: string, b: any) => { await boot(); const d = await api(`/api/orders/${id}/${a}`, b); if (d.ok !== true) throw new Error("Server did not confirm"); await refresh(); };
export const liveA = {
  track: (name: string) => { boot().then(() => api("/api/events", { name })).catch(() => {}); }, // analytics only
  async place(key: string, table: string, items: Line[]) {
    await boot(); const d = await api("/api/orders", { key, table, items: items.map((l) => ({ id: l.id, size: l.size, ex: l.ex, q: l.q })) });
    if (typeof d.id !== "string") throw new Error("Server did not confirm the order"); await refresh(); return d.id;
  },
  advance: (id: any, to: string) => act(id, "status", { to }),
  pay: (id: any) => act(id, "pay", {}),
  feedback: (id: any, f: Fb) => act(id, "feedback", { food: f.food, service: f.service, ambience: f.amb }),
  async join(code: string) { await boot(); const d = await api("/api/session", { code }); if (typeof d.code !== "string") throw new Error("Bad response"); upd({ code: d.code }); await refresh(); },
  lead: (_: any) => {},
};
