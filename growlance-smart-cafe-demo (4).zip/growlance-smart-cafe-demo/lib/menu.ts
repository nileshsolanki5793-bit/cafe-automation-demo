export type Item = { id: number; cat: string; name: string; slug: string; price: number; desc: string; tone: string };
export const MENU: Item[] = [
  { id: 1, cat: "Coffee", name: "Cappuccino", slug: "cappuccino", price: 180, desc: "Double shot, velvety foam", tone: "from-amber-700 to-amber-900" },
  { id: 2, cat: "Coffee", name: "Cold Coffee", slug: "cold-coffee", price: 220, desc: "Slow-brewed, chilled, creamy", tone: "from-stone-500 to-stone-800" },
  { id: 3, cat: "Coffee", name: "Masala Chai", slug: "masala-chai", price: 120, desc: "Ginger, cardamom, strong tea", tone: "from-orange-600 to-amber-800" },
  { id: 4, cat: "Bites", name: "Veg Club Sandwich", slug: "club-sandwich", price: 190, desc: "Grilled, three layers, mint mayo", tone: "from-lime-600 to-green-800" },
  { id: 5, cat: "Bites", name: "Creamy Pasta", slug: "pasta", price: 280, desc: "Penne in white sauce, herbs", tone: "from-yellow-500 to-orange-700" },
  { id: 6, cat: "Bites", name: "Peri Peri Fries", slug: "fries", price: 150, desc: "Crisp, spicy, shareable", tone: "from-red-500 to-orange-700" },
  { id: 7, cat: "Dessert", name: "Walnut Brownie", slug: "brownie", price: 170, desc: "Warm, fudgy, with ice cream", tone: "from-stone-700 to-stone-900" },
  { id: 8, cat: "Dessert", name: "Blueberry Cheesecake", slug: "cheesecake", price: 240, desc: "Baked, silky, buttery base", tone: "from-indigo-500 to-purple-800" },
];
export const SIZES: [string, number][] = [["Regular", 0], ["Large", 40]];
export const EXTRAS: [string, number][] = [["Extra shot", 30], ["Oat milk", 40], ["Whipped cream", 25]];
