import { createHash } from "crypto";
import { NextResponse } from "next/server";
import { admin } from "./supabaseAdmin";
export const J = (b: any, s = 200) => NextResponse.json(b, { status: s });
export const EVENTS = ["landing_visit", "demo_started", "product_selected", "order_placed", "order_confirmed", "demo_payment_completed", "feedback_submitted", "lead_form_opened", "lead_submitted"];
export const ipKey = (req: Request, k: string) => {
  const ip = req.headers.get("x-nf-client-connection-ip") ?? (req.headers.get("x-forwarded-for") ?? "unknown").split(",")[0].trim();
  return k + ":" + createHash("sha256").update(ip + (process.env.IP_HASH_SALT ?? "")).digest("hex");
};
// Atomic DB-side limiter (rate_limit_hit). Fails CLOSED: if the limiter errors, the request is refused.
export async function limited(db: any, key: string, max: number, mins = 60) {
  const { data, error } = await db.rpc("rate_limit_hit", { p_key: key, p_max: max, p_mins: mins });
  if (error) { console.error("rate limit failed", error.message); return true; }
  return data === true;
}
// Verifies the caller's Supabase Auth access token (anonymous or real user) server-side.
export async function who(req: Request): Promise<any> {
  const db = admin(); if (!db) return { err: J({ error: "Backend not configured" }, 503) };
  const t = (req.headers.get("authorization") ?? "").replace(/^Bearer /, "");
  if (!t) return { err: J({ error: "Not signed in" }, 401) };
  const { data, error } = await db.auth.getUser(t);
  if (error || !data.user) return { err: J({ error: "Not signed in" }, 401) };
  return { db, user: data.user };
}
export async function ctx(req: Request): Promise<any> {
  const w = await who(req); if (w.err) return w;
  const { data, error } = await w.db.from("session_members").select("session_id,demo_sessions!inner(expires_at)").eq("user_id", w.user.id).maybeSingle();
  if (error) return { err: J({ error: "Database error" }, 500) };
  if (!data || new Date((data as any).demo_sessions.expires_at) < new Date()) return { err: J({ error: "No active demo session" }, 401) };
  return { db: w.db, sid: data.session_id, user: w.user };
}
export async function adminCtx(req: Request, k: string, max: number): Promise<any> {
  const db = admin(); if (!db) return { err: J({ error: "Backend not configured" }, 503) };
  if (await limited(db, ipKey(req, k), max)) return { err: J({ error: "Too many requests" }, 429) };
  const w = await who(req); if (w.err) return w;
  const ok = (process.env.ADMIN_EMAILS ?? "").toLowerCase().split(",").map((s) => s.trim()).filter(Boolean);
  const e = w.user.email?.toLowerCase();
  if (!e || !w.user.email_confirmed_at || !ok.includes(e)) return { err: J({ error: "Forbidden" }, 403) };
  return { db, user: w.user };
}
