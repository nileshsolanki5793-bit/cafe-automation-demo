"use client";
import { createClient, SupabaseClient } from "@supabase/supabase-js";
let c: SupabaseClient | null = null;
export const getSb = () => (c ??= createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!));
