export const NEXT = { placed: "confirmed", confirmed: "preparing", preparing: "completed" } as const;
export const canMove = (from: string, to: string) => NEXT[from as keyof typeof NEXT] === to;
