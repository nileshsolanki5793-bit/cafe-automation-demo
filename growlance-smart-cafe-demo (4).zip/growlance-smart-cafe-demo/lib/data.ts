import { useLocal, localA } from "./store";
import { useLive, liveA } from "./live";
export const LIVE = !!process.env.NEXT_PUBLIC_SUPABASE_URL && !!process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
export const useStore: any = LIVE ? useLive : useLocal;
export const A: any = LIVE ? liveA : localA;
