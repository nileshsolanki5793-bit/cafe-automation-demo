import { createClient } from "@supabase/supabase-js";
// Server-only. Returns null when credentials are missing so routes can fail honestly.
export function admin() {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL, key = process.env.SUPABASE_SERVICE_ROLE_KEY;
  return url && key ? createClient(url, key, { auth: { persistSession: false } }) : null;
}
