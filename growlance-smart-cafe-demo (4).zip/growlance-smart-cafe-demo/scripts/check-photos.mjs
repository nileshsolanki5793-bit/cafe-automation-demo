import { existsSync } from "fs";
const slugs = ["cappuccino","cold-coffee","masala-chai","club-sandwich","pasta","fries","brownie","cheesecake"];
const missing = slugs.filter((s) => !existsSync(`public/menu/${s}.jpg`));
console.log(missing.length ? "Missing real photos (placeholders will show): " + missing.join(", ") : "All 8 photos present.");
