export default {content:["./app/**/*.{ts,tsx}"],theme:{extend:{colors:{g:"#25A65A",k:"#111216",l:"#E6E7EC",y:"#F8C95A"}}}};
