// Netlify scheduled function. UNVERIFIED on a real deploy: confirm it appears and runs under Functions in the Netlify dashboard.
export default async () => {
  const base = process.env.URL, secret = process.env.CRON_SECRET;
  if (!base || !secret) { console.error("maintenance: URL or CRON_SECRET missing"); return; }
  const r = await fetch(base + "/api/internal/maintenance", { method: "POST", headers: { "x-cron-secret": secret } });
  console.log("maintenance", r.status, await r.text());
};
export const config = { schedule: "*/5 * * * *" };
