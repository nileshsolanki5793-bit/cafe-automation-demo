"use client";
import { useEffect, useState } from "react";
import { MENU, SIZES, EXTRAS, Item } from "@/lib/menu";
import { useStore, A, LIVE } from "@/lib/data";
import type { Order, Line } from "@/lib/store";
const inr = (n: number) => "₹" + n.toLocaleString("en-IN");
const btn = "rounded-xl px-4 py-3 font-bold ";
const pri = btn + "bg-g text-white shadow-lg shadow-g/30 disabled:opacity-50", alt = btn + "bg-white border border-black/10";

function Photo({ it, h = "h-28" }: { it: Item; h?: string }) {
  const [bad, setBad] = useState(false), [ext, setExt] = useState("jpg");
  return bad ? (
    <div className={`${h} rounded-xl bg-gradient-to-br ${it.tone} grid place-items-center text-center text-[10px] text-white/80 p-1`}>PHOTO PLACEHOLDER<br />public/menu/{it.slug}.jpg</div>
  ) : <img src={`/menu/${it.slug}.${ext}`} alt={it.name} loading="lazy" width={400} height={300} onError={() => (ext === "jpg" ? setExt("svg") : setBad(true))} className={`${h} w-full rounded-xl object-cover`} />;
}

export default function Home() {
  const store: any = useStore(); const { orders, events } = store; const LV = LIVE ? store.status : null;
  useEffect(() => { A.track("landing_visit"); }, []);
  const [mode, setMode] = useState<"landing" | "customer" | "owner">("landing");
  const [cat, setCat] = useState("Coffee"), [sheet, setSheet] = useState<Item | null>(null), [cart, setCart] = useState<Line[]>([]);
  const [cartOpen, setCartOpen] = useState(false), [table, setTable] = useState("4"), [curId, setCurId] = useState<any>(null);
  const [key, setKey] = useState(() => Math.random().toString(36).slice(2)), [lead, setLead] = useState(false), [toast, setToast] = useState("");
  const cur = orders.find((o) => o.id === curId);
  const say = (t: string) => { setToast(t); setTimeout(() => setToast(""), 2800); };
  const run = async (f: () => any) => { try { await f(); return true; } catch (e: any) { say(e.message || "Action failed"); return false; } };
  const start = () => { A.track("demo_started"); setMode("customer"); };
  const place = async () => { let id: any; try { id = await A.place(key, table, cart); } catch (e: any) { say(e.message || "Order failed"); return; } setCurId(id); setCart([]); setCartOpen(false); setKey(Math.random().toString(36).slice(2)); say("Order placed"); };
  const g = cur && (cur.status === "placed" ? (mode === "customer" ? { t: "Ab Cafe Owner Bankar Order Confirm Karo!", b: "Open Owner Mode", go: "owner" } : { t: "Order aa gaya! Confirm Order dabao." })
    : cur.status === "completed" && mode === "owner" ? { t: "Order complete! Customer Mode mein bill, payment aur feedback dekho.", b: "Back to Customer", go: "customer" }
    : mode === "owner" ? { t: "Confirmed! Customer Mode mein live status dekho.", b: "Back to Customer", go: "customer" }
    : cur.status === "completed" ? (!cur.paid ? { t: "Order ready! Ab bill ka test payment karo." } : !cur.fb ? { t: "Last step: Food, Service aur Ambience feedback do." } : { t: "Ab Ye Apne Cafe Ke Naam Se Dekho!" })
    : { t: "Owner ne confirm kiya! Ab Owner Mode mein order ko Completed tak le jao.", b: "Open Owner Mode", go: "owner" });

  if (mode === "landing") return (
    <main className="min-h-screen bg-k text-white grid place-items-center text-center p-6">
      <div className="max-w-md up"><span className="bg-g text-xs font-bold px-3 py-1 rounded-full">GROWLANCE DIGITAL</span>
        <h1 className="text-4xl font-extrabold my-4 leading-tight">Agar Ye Aapka Cafe Hota Toh?</h1>
        <p className="text-white/70 mb-6">Khud order karo, phir dekho cafe owner ko order kaise milta hai.</p>
        <button className={pri + " text-lg w-full"} onClick={start}>TRY FREE INTERACTIVE DEMO</button>
        <p className="text-xs text-white/50 mt-3">No signup · No payment · {LIVE ? "Test mode" : "Local preview mode"}</p>{LIVE && <Join onJoined={() => setMode("owner")} />}</div></main>);

  return (
    <main className="max-w-md md:max-w-5xl mx-auto p-3 pb-24">
      <div className={"text-[11px] font-bold text-center rounded-lg py-1 mb-2 " + (!LIVE ? "bg-y text-k" : LV === "live" ? "bg-g text-white" : LV === "error" ? "bg-red-600 text-white" : LV === "reconnecting" ? "bg-y text-k" : "bg-l")}>{!LIVE ? "PREVIEW MODE — local simulation. Syncs only across tabs of this browser, not between devices" : LV === "live" ? "LIVE CONNECTED MODE — Supabase Realtime" : LV === "error" ? "Backend unreachable — check Supabase and Netlify settings" : LV === "reconnecting" ? "Reconnecting… live updates paused, this screen may be out of date" : "Connecting…"}</div>
      {LIVE && store.code && <p className="text-xs text-center mb-2">Session code <b className="tracking-widest">{store.code}</b> · on another device open this site and tap “Join with code”</p>}
      {g && <div className="bg-k text-white rounded-2xl p-3 mb-3 flex items-center justify-between gap-2 up" role="status"><b>{g.t}</b>{g.b && <button className={pri + " shrink-0"} onClick={() => setMode((g as any).go)}>{g.b}</button>}</div>}
      <div className="md:grid md:grid-cols-2 md:gap-4">
        <section className={(mode === "customer" ? "" : "hidden md:block ") + "bg-white rounded-3xl p-4 up"} aria-label="Customer mode">
          {!cur ? <>
            <h2 className="text-xl font-extrabold">Brew &amp; Bloom Café</h2><p className="text-sm text-black/50">Table {table} · Demo menu</p>
            <div className="flex gap-2 my-3 overflow-x-auto">{["Coffee", "Bites", "Dessert"].map((c) => <button key={c} onClick={() => setCat(c)} className={btn + (c === cat ? "bg-k text-white" : "bg-l")}>{c}</button>)}</div>
            <div className="grid grid-cols-2 gap-3">{MENU.filter((m) => m.cat === cat).map((m) =>
              <button key={m.id} onClick={() => { A.track("product_selected"); setSheet({ ...m }); }} className="bg-l rounded-2xl p-2 text-left hover:-translate-y-1 transition">
                <Photo it={m} /><b className="block mt-2">{m.name}</b><span className="text-xs text-black/60">{m.desc}</span><b className="block text-g">{inr(m.price)}</b></button>)}</div>
            {cart.length > 0 && <button className={pri + " w-full mt-4"} onClick={() => setCartOpen(true)}>View cart · {inr(cart.reduce((s, l) => s + l.price * l.q, 0))}</button>}
          </> : <Track o={cur} onPay={async () => { const ok = await run(() => A.pay(cur.id)); if (ok) say("Demo payment recorded"); return ok; }} onFb={(f: any) => run(() => A.feedback(cur.id, f))} onLead={() => { A.track("lead_form_opened"); setLead(true); }} onAgain={() => setCurId(null)} />}
        </section>
        <section className={(mode === "owner" ? "" : "hidden md:block ") + "bg-white rounded-3xl p-4 mt-3 md:mt-0"} aria-label="Cafe owner mode">
          <h2 className="text-xl font-extrabold">Owner dashboard</h2>
          {!orders.length && <p className="text-black/50 py-12 text-center">No orders yet. Place one as the customer.</p>}
          {orders.map((o) => { const nx = ({ placed: ["confirmed", "Confirm Order"], confirmed: ["preparing", "Start Preparing"], preparing: ["completed", "Mark Completed"] } as any)[o.status];
            return <div key={o.id} className={"border rounded-2xl p-3 my-3 up " + (o.status === "placed" ? "border-g ring-2 ring-g/30" : "border-black/10")}>
              <div className="flex justify-between"><b>#{o.no} · Table {o.table}</b><span className="text-xs font-bold bg-y px-2 py-1 rounded-full">{o.status.toUpperCase()}</span></div>
              {o.items.map((l, i) => <p key={i} className="text-sm text-black/60">{l.q}× {l.name} — {l.opt}</p>)}
              <p className="flex justify-between my-2"><b>{inr(o.total)}</b><span className="text-xs font-bold">{o.paid ? "DEMO PAID" : "UNPAID"}</span></p>
              {nx && <button className={pri + " w-full"} onClick={() => run(() => A.advance(o.id, nx[0]))}>{nx[1]}</button>}
              {o.fb && <p className="text-sm mt-2">⭐ Food {o.fb.food} · Service {o.fb.service} · Ambience {o.fb.amb}</p>}</div>; })}
          {!LIVE && <p className="text-[11px] text-black/40">Tracked events (local): {events.length}</p>}
        </section></div>
      <nav className="md:hidden fixed bottom-0 inset-x-0 bg-white border-t p-2 flex gap-2" style={{ paddingBottom: "calc(8px + env(safe-area-inset-bottom))" }}>
        {(["customer", "owner"] as const).map((m) => <button key={m} onClick={() => setMode(m)} className={btn + "flex-1 " + (mode === m ? "bg-k text-white" : "bg-l")}>{m === "customer" ? "Customer" : "Cafe Owner"}</button>)}</nav>
      {sheet && <ItemSheet it={sheet} onClose={() => setSheet(null)} onAdd={(l) => { setCart((c) => [...c, l]); setSheet(null); say(l.name + " added"); }} />}
      {cartOpen && <Modal onClose={() => setCartOpen(false)}><h3 className="font-extrabold text-lg">Your cart</h3>
        {cart.map((l, i) => <div key={i} className="flex justify-between my-2"><span>{l.q}× {l.name}<br /><small className="text-black/50">{l.opt}</small></span><span>{inr(l.price * l.q)} <button aria-label="Remove" onClick={() => setCart(cart.filter((_, j) => j !== i))}>✕</button></span></div>)}
        <label className="text-sm">Table <select value={table} onChange={(e) => setTable(e.target.value)} className="border rounded p-2 ml-2">{[1, 2, 3, 4, 5, 6].map((n) => <option key={n}>{n}</option>)}</select></label>
        <button className={pri + " w-full mt-3"} disabled={!cart.length} onClick={place}>Place order</button></Modal>}
      {lead && <LeadForm onClose={() => setLead(false)} />}
      {toast && <div className="fixed top-3 inset-x-0 mx-auto w-fit bg-k text-white px-4 py-2 rounded-xl border-l-4 border-g up" role="status">{toast}</div>}
    </main>);
}

function Modal({ children, onClose }: { children: React.ReactNode; onClose: () => void }) {
  return <div className="fixed inset-0 bg-black/60 grid items-end md:place-items-center z-20" onClick={onClose}><div className="bg-white rounded-t-3xl md:rounded-3xl p-5 max-h-[90vh] overflow-auto max-w-md w-full mx-auto up" role="dialog" aria-modal="true" onClick={(e) => e.stopPropagation()}>{children}</div></div>;
}
function ItemSheet({ it, onClose, onAdd }: { it: Item; onClose: () => void; onAdd: (l: Line) => void }) {
  const [sz, setSz] = useState(0), [ex, setEx] = useState<number[]>([]), [q, setQ] = useState(1);
  const price = it.price + SIZES[sz][1] + ex.reduce((s, i) => s + EXTRAS[i][1], 0);
  const chip = (on: boolean) => "rounded-full border px-3 py-2 m-1 font-semibold " + (on ? "bg-g text-white border-g" : "bg-white");
  return <Modal onClose={onClose}><Photo it={it} h="h-36" /><h3 className="font-extrabold text-lg mt-2">{it.name}</h3><p className="text-sm text-black/60">{it.desc}</p>
    <p className="font-bold mt-2">Size</p>{SIZES.map((s, i) => <button key={s[0]} className={chip(sz === i)} onClick={() => setSz(i)}>{s[0]}{s[1] ? ` +₹${s[1]}` : ""}</button>)}
    <p className="font-bold mt-2">Extras</p>{EXTRAS.map((x, i) => <button key={x[0]} className={chip(ex.includes(i))} onClick={() => setEx(ex.includes(i) ? ex.filter((e) => e !== i) : [...ex, i])}>{x[0]} +₹{x[1]}</button>)}
    <div className="flex justify-between items-center mt-4"><span><button className={alt} aria-label="Less" onClick={() => setQ(Math.max(1, q - 1))}>−</button> <b className="mx-2">{q}</b> <button className={alt} aria-label="More" onClick={() => setQ(Math.min(9, q + 1))}>+</button></span>
      <button className={pri} onClick={() => onAdd({ id: it.id, size: sz, ex, name: it.name, opt: SIZES[sz][0] + ex.map((i) => " + " + EXTRAS[i][0]).join(""), price, q })}>Add · {inr(price * q)}</button></div></Modal>;
}
function Track({ o, onPay, onFb, onLead, onAgain }: { o: Order; onPay: () => any; onFb: (f: any) => any; onLead: () => void; onAgain: () => void }) {
  const steps = ["placed", "confirmed", "preparing", "completed"], i = steps.indexOf(o.status), [f, setF] = useState({ food: 0, service: 0, amb: 0 }), [paying, setPaying] = useState(false);
  const rv = process.env.NEXT_PUBLIC_GOOGLE_REVIEW_URL;
  return <div className="up"><div className="flex justify-between"><h2 className="text-xl font-extrabold">Order #{o.no}</h2><b className="text-xs bg-y px-2 py-1 rounded-full">{o.status.toUpperCase()}</b></div>
    <div className="flex gap-1 my-3">{steps.map((s, k) => <i key={s} className={"flex-1 h-1.5 rounded " + (k <= i ? "bg-g" : "bg-l")} />)}</div>
    <div className="border rounded-2xl p-3">{o.items.map((l, k) => <p key={k} className="flex justify-between text-sm"><span>{l.q}× {l.name} <small className="text-black/50">{l.opt}</small></span>{inr(l.price * l.q)}</p>)}
      <p className="flex justify-between text-sm border-t mt-2 pt-2">GST 5%<span>{inr(o.total - o.sub)}</span></p><p className="flex justify-between font-extrabold">Total<span>{inr(o.total)}</span></p></div>
    {i > 0 && !o.fb && <button className="text-g font-bold underline mt-2" onClick={onLead}>Apne Cafe Ke Naam Se Ye System Dekhna Hai?</button>}
    {o.status === "completed" && !o.paid && <><p className="bg-y text-center font-extrabold text-xs rounded-lg py-2 mt-3">DEMO PAYMENT — NO MONEY WILL BE CHARGED</p>
      <button className={pri + " w-full mt-2"} disabled={paying} onClick={() => { setPaying(true); setTimeout(async () => { if (!(await onPay())) setPaying(false); }, 800); }}>{paying ? "Processing test payment…" : `Pay ${inr(o.total)} (test)`}</button></>}
    {o.paid && !o.fb && <div className="border rounded-2xl p-3 mt-3"><b>How was it?</b>{([["food", "Food"], ["service", "Service"], ["amb", "Ambience"]] as const).map(([k, l]) =>
      <p key={k} className="flex justify-between items-center">{l}<span>{[1, 2, 3, 4, 5].map((n) => <button key={n} aria-label={`${n} stars for ${l}`} className={"text-2xl px-0.5 " + (f[k] >= n ? "text-y" : "text-black/20")} onClick={() => setF({ ...f, [k]: n })}>★</button>)}</span></p>)}
      <button className={pri + " w-full mt-2"} disabled={!f.food || !f.service || !f.amb} onClick={() => onFb(f)}>Submit feedback</button></div>}
    {o.fb && <div className="border rounded-2xl p-3 mt-3"><b>Thank you for your feedback!</b>
      <p className="text-sm text-black/60 my-2">Optional: if you enjoyed this cafe, you may share a genuine Google review. Nothing is posted unless you write and submit it yourself. This option is the same for everyone.</p>
      {rv ? <a className={alt + " block text-center"} href={rv} target="_blank" rel="noreferrer">Leave a Google review (optional)</a> : <p className="text-xs text-black/40">(Review link not configured: set NEXT_PUBLIC_GOOGLE_REVIEW_URL)</p>}
      <p className="text-sm mt-3">Growlance also offers free help with Google Business Profile promotion. No guaranteed rankings or results.</p>
      <button className={pri + " w-full mt-2"} onClick={onLead}>GET MY CAFE DEMO</button></div>}
    <button className={alt + " w-full mt-3"} onClick={onAgain}>+ Order again</button></div>;
}
function LeadForm({ onClose }: { onClose: () => void }) {
  const [v, setV] = useState({ cafeName: "", city: "", phone: "", contactMethod: "WhatsApp", marketingConsent: false, website: "" });
  const [st, setSt] = useState<"idle" | "busy" | "ok" | "local" | "err">("idle"), [msg, setMsg] = useState("");
  const inp = "w-full border rounded-lg p-3 my-1 bg-l";
  async function submit(e: React.FormEvent) {
    e.preventDefault(); setSt("busy"); setMsg("");
    try {
      const r = await fetch("/api/leads", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(v) });
      if (r.ok) { setSt("ok"); }
      else if (r.status === 503) { setSt("local"); } // backend not configured
      else { setMsg((await r.json()).error || "Something went wrong."); setSt("err"); }
    } catch { setMsg("Network error. Your request was NOT received."); setSt("err"); }
  }
  return <Modal onClose={onClose}>{st === "ok" ? <><h3 className="font-extrabold text-lg">Request received ✓</h3><p>Growlance will contact you via {v.contactMethod}.</p><button className={pri + " mt-3"} onClick={onClose}>Done</button></>
    : st === "local" ? <><h3 className="font-extrabold text-lg">Not sent to Growlance</h3><p className="text-sm">Backend isn’t configured, so your request was NOT saved or sent. Growlance received nothing. Please try again once the live backend is connected.</p><button className={pri + " mt-3"} onClick={onClose}>Close</button></>
    : <form onSubmit={submit}><h3 className="font-extrabold text-lg">You’ve Experienced Smart Cafe Ordering!</h3><p className="text-sm text-black/60">Ab Ye Apne Cafe Ke Naam Se Dekho!</p>
      <input className={inp} required placeholder="Cafe name" value={v.cafeName} onChange={(e) => setV({ ...v, cafeName: e.target.value })} />
      <input className={inp} required placeholder="City" value={v.city} onChange={(e) => setV({ ...v, city: e.target.value })} />
      <input className={inp} required inputMode="numeric" maxLength={10} placeholder="10-digit mobile number" value={v.phone} onChange={(e) => setV({ ...v, phone: e.target.value })} />
      <select className={inp} value={v.contactMethod} onChange={(e) => setV({ ...v, contactMethod: e.target.value })}><option>WhatsApp</option><option>Phone call</option></select>
      <input className="hidden" tabIndex={-1} autoComplete="off" aria-hidden value={v.website} onChange={(e) => setV({ ...v, website: e.target.value })} />
      <p className="text-xs text-black/60">By submitting, you ask Growlance to contact you about this demo request.</p>
      <label className="flex gap-2 text-sm my-2"><input type="checkbox" checked={v.marketingConsent} onChange={(e) => setV({ ...v, marketingConsent: e.target.checked })} />Optional: I also agree to marketing follow-ups.</label>
      {msg && <p className="text-red-600 text-sm" role="alert">{msg}</p>}
      <button className={pri + " w-full"} disabled={st === "busy"}>{st === "busy" ? "Sending…" : "GET MY CAFE DEMO"}</button></form>}</Modal>;
}

function Join({ onJoined }: { onJoined: () => void }) {
  const [c, setC] = useState(""), [e, setE] = useState(""), [busy, setBusy] = useState(false);
  async function go() { setBusy(true); setE(""); try { await A.join(c); onJoined(); } catch (x: any) { setE(x.message); } setBusy(false); }
  return <div className="mt-8 text-sm"><p className="text-white/60">Second device? Join the demo started on another device (to be the Cafe Owner):</p>
    <div className="flex gap-2 mt-2"><input aria-label="Session code" className="flex-1 rounded-lg p-3 bg-white/10 uppercase tracking-widest text-center" maxLength={6} placeholder="CODE" value={c} onChange={(x) => setC(x.target.value)} />
      <button className="rounded-xl px-4 font-bold bg-y text-k disabled:opacity-50" disabled={c.length < 6 || busy} onClick={go}>Join with code</button></div>{e && <p className="text-red-400 mt-1" role="alert">{e}</p>}</div>;
}
