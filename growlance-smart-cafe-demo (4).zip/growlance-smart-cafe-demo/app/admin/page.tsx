"use client";
import { useState } from "react";
import { getSb } from "@/lib/browserClient";
const ORDER = ["landing_visit", "demo_started", "product_selected", "order_placed", "order_confirmed", "demo_payment_completed", "feedback_submitted", "lead_form_opened", "lead_submitted"];
export default function Admin() {
  const [f, setF] = useState({ email: "", pw: "" }), [note, setNote] = useState(""), [d, setD] = useState<any>(null), [err, setErr] = useState("");
  const call = async (path: string, body?: any) => {
    const { data } = await getSb().auth.getSession();
    const r = await fetch(path, { method: body ? "POST" : "GET", headers: { "content-type": "application/json", authorization: "Bearer " + data.session?.access_token }, body: body ? JSON.stringify(body) : undefined });
    const j = await r.json().catch(() => ({})); if (!r.ok) throw new Error(j.error || "Failed"); return j;
  };
  async function login(e: React.FormEvent) {
    e.preventDefault(); setErr("");
    try { const r = await getSb().auth.signInWithPassword({ email: f.email, password: f.pw }); if (r.error) throw new Error("Sign-in failed"); setD(await call("/api/admin/summary")); }
    catch (x: any) { setErr(x.message); }
  }
  async function retry() { try { const r = await call("/api/admin/retry", {}); setNote(r.configured ? `Retried: ${r.sent} sent, ${r.failed} failed` : "N8N_WEBHOOK_URL is not set"); setD(await call("/api/admin/summary")); } catch (x: any) { setErr(x.message); } }
  async function reveal(i: number) { try { const r = await call("/api/admin/reveal", { id: d.leads[i].id }); const l = [...d.leads]; l[i] = { ...l[i], phone: r.phone }; setD({ ...d, leads: l }); } catch (x: any) { setErr(x.message); } }
  return <main className="max-w-4xl mx-auto p-4"><h1 className="text-2xl font-extrabold mb-3">Growlance admin</h1>
    {err && <p className="text-red-600" role="alert">{err}</p>}
    {!d ? <form onSubmit={login} className="grid gap-2 max-w-sm"><input type="email" required autoComplete="username" className="border rounded-lg p-3" placeholder="Admin email" value={f.email} onChange={(e) => setF({ ...f, email: e.target.value })} />
      <input type="password" required autoComplete="current-password" className="border rounded-lg p-3" placeholder="Password" value={f.pw} onChange={(e) => setF({ ...f, pw: e.target.value })} /><button className="bg-g text-white font-bold rounded-xl p-3">Sign in</button></form> : <>
      <button className="underline text-sm" onClick={async () => { await getSb().auth.signOut(); setD(null); }}>Sign out</button>
      <p className="text-sm my-2">n8n notifications — sent: {d.notify?.sent ?? 0} · pending: {d.notify?.pending ?? 0} · failed: {d.notify?.failed ?? 0} · dead: {d.notify?.dead ?? 0} <button className="underline text-g ml-2" onClick={retry}>Retry now</button> {note}</p>
      <div className="grid grid-cols-2 md:grid-cols-3 gap-3 my-4">{ORDER.map((k) => <div key={k} className="bg-white rounded-2xl p-3"><p className="text-xs text-black/50">{k.replace(/_/g, " ")}</p><b className="text-2xl text-g">{d.counts[k] ?? 0}</b></div>)}</div>
      <div className="bg-white rounded-2xl p-3 overflow-x-auto"><table className="w-full text-sm"><thead><tr className="text-left"><th>Date</th><th>Cafe</th><th>City</th><th>Phone</th><th>Via</th><th>Marketing</th></tr></thead>
        <tbody>{d.leads.map((l: any, i: number) => <tr key={l.id} className="border-t"><td>{new Date(l.created_at).toLocaleString()}</td><td>{l.cafe_name}</td><td>{l.city}</td><td>{l.phone} {l.phone.includes("X") && <button className="underline text-g" onClick={() => reveal(i)}>Reveal</button>}</td><td>{l.contact_method}</td><td>{l.marketing_consent ? "Yes" : "No"}</td></tr>)}</tbody></table>
        {!d.leads.length && <p className="text-black/50 p-3">No leads yet.</p>}</div></>}</main>;
}
