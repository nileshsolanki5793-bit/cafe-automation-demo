import { ctx, J, EVENTS, limited } from "@/lib/server";
export async function POST(req: Request) {
  const c = await ctx(req); if (c.err) return c.err;
  if (await limited(c.db, "ev:" + c.user.id, 200)) return J({ error: "Too many events" }, 429);
  const b = await req.json().catch(() => null);
  if (!EVENTS.includes(b?.name)) return J({ error: "Unknown event" }, 422);
  await c.db.from("events").insert({ session_id: c.sid, name: b.name }); return J({ ok: true });
}
