import { ctx, J } from "@/lib/server";
import { canMove } from "@/lib/transitions";
// Success ({ok:true}) is returned ONLY after the database confirms the write (or confirms an identical earlier write exists).
export async function POST(req: Request, { params }: { params: Promise<{ id: string; action: string }> }) {
  try {
    const c = await ctx(req); if (c.err) return c.err; const { db, sid } = c, { id, action } = await params;
    if (!/^[0-9a-f-]{36}$/.test(id)) return J({ error: "Invalid order" }, 422);
    const b = await req.json().catch(() => ({}));
    const { data: o, error: oe } = await db.from("orders").select("*").eq("id", id).eq("session_id", sid).maybeSingle(); // session-scoped
    if (oe) return J({ error: "Database error" }, 500);
    if (!o) return J({ error: "Order not found" }, 404);
    const ev = (name: string) => db.from("events").insert({ session_id: sid, name }); // analytics: failure must not change the result
    if (action === "status") {
      if (!canMove(o.status, b.to)) return J({ error: "Invalid status change" }, 409);
      const { data, error } = await db.from("orders").update({ status: b.to }).eq("id", id).eq("status", o.status).select("id");
      if (error) return J({ error: "Could not update the order" }, 500);
      if (!data?.length) return J({ error: "Order changed on another device. Refresh and retry." }, 409);
      if (b.to === "confirmed") await ev("order_confirmed"); return J({ ok: true });
    }
    if (action === "pay") {
      if (o.status !== "completed") return J({ error: "Order not completed yet" }, 409);
      const { error } = await db.from("payments").insert({ order_id: id }); // demo payment record only
      if (error && error.code !== "23505") return J({ error: "Payment could not be recorded. Please retry." }, 500);
      if (!error) await ev("demo_payment_completed"); // 23505 = already recorded: truthful, idempotent success
      return J({ ok: true, duplicate: !!error });
    }
    if (action === "feedback") {
      const f = [b.food, b.service, b.ambience]; if (f.some((n) => !Number.isInteger(n) || n < 1 || n > 5)) return J({ error: "Ratings must be 1-5" }, 422);
      const { data: p, error: pe } = await db.from("payments").select("order_id").eq("order_id", id).maybeSingle();
      if (pe) return J({ error: "Database error" }, 500);
      if (!p) return J({ error: "Complete the demo payment first" }, 409);
      const { error } = await db.from("feedback").insert({ order_id: id, food: b.food, service: b.service, ambience: b.ambience });
      if (error && error.code !== "23505") return J({ error: "Feedback could not be saved. Please retry." }, 500);
      if (!error) await ev("feedback_submitted"); return J({ ok: true, duplicate: !!error });
    }
    return J({ error: "Unknown action" }, 404);
  } catch { return J({ error: "Unexpected server error" }, 500); }
}
