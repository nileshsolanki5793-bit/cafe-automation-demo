import { ctx, J } from "@/lib/server";
import { MENU, SIZES, EXTRAS } from "@/lib/menu";
// Prices, names and totals come ONLY from lib/menu.ts. The client sends ids, size index, extra indexes and quantity.
export async function POST(req: Request) {
  const c = await ctx(req); if (c.err) return c.err; const { db, sid } = c;
  const b = await req.json().catch(() => null), raw = Array.isArray(b?.items) ? b.items : [], table = Number(b?.table);
  if (!b?.key || String(b.key).length > 64 || !raw.length || raw.length > 20 || !Number.isInteger(table) || table < 1 || table > 20) return J({ error: "Invalid order" }, 422);
  const lines: any[] = [];
  for (const r of raw) {
    const it = MENU.find((m) => m.id === r?.id), size = Number(r?.size ?? 0), q = Number(r?.q), ex: number[] = Array.isArray(r?.ex) ? r.ex : [];
    if (!it || !SIZES[size] || !Number.isInteger(q) || q < 1 || q > 9 || ex.length > EXTRAS.length || new Set(ex).size !== ex.length || ex.some((e) => !Number.isInteger(e) || !EXTRAS[e])) return J({ error: "Invalid item" }, 422);
    lines.push({ name: it.name, opt: SIZES[size][0] + ex.map((e) => " + " + EXTRAS[e][0]).join(""), unit: it.price + SIZES[size][1] + ex.reduce((s, e) => s + EXTRAS[e][1], 0), q });
  }
  const dup = await db.from("orders").select("id").eq("session_id", sid).eq("idempotency_key", b.key).maybeSingle();
  if (dup.data) return J({ id: dup.data.id });
  const cnt = await db.from("orders").select("id", { count: "exact", head: true }).eq("session_id", sid);
  if ((cnt.count ?? 0) >= 25) return J({ error: "Order limit reached for this demo session" }, 429);
  const sub = lines.reduce((s, l) => s + l.unit * l.q, 0), total = sub + Math.round(sub * 0.05);
  const { data: o, error } = await db.from("orders").insert({ session_id: sid, idempotency_key: b.key, table_no: table, subtotal: sub, total }).select("id").single();
  if (error) return J({ error: "Could not place order" }, 500);
  const ins = await db.from("order_items").insert(lines.map((l) => ({ order_id: o.id, name: l.name, options: l.opt, unit_price: l.unit, qty: l.q })));
  if (ins.error) { await db.from("orders").delete().eq("id", o.id); return J({ error: "Could not place order" }, 500); }
  await db.from("events").insert({ session_id: sid, name: "order_placed" }); return J({ id: o.id });
}
