import { randomInt } from "crypto";
import { who, J, limited, ipKey } from "@/lib/server";
const AL = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789", gen = () => Array.from({ length: 6 }, () => AL[randomInt(AL.length)]).join("");
// Creates this visitor's demo session, or joins another device's session by 6-character code (24h expiry).
// Success is returned ONLY after the membership row is confirmed saved.
export async function POST(req: Request) {
  const w = await who(req); if (w.err) return w.err; const { db, user } = w;
  const b = await req.json().catch(() => ({}));
  const member = (sid: string) => db.from("session_members").upsert({ user_id: user.id, session_id: sid }).select("user_id");
  if (b.code) {
    if (await limited(db, ipKey(req, "join"), 15)) return J({ error: "Too many attempts. Try later." }, 429);
    const { data: s, error } = await db.from("demo_sessions").select("id,join_code").eq("join_code", String(b.code).toUpperCase().slice(0, 6)).gt("expires_at", new Date().toISOString()).maybeSingle();
    if (error) return J({ error: "Database error" }, 500);
    if (!s) return J({ error: "Code not found or expired" }, 404);
    const m = await member(s.id); if (m.error || !m.data?.length) return J({ error: "Could not join the session" }, 500);
    return J({ code: s.join_code });
  }
  const ex = await db.from("session_members").select("demo_sessions!inner(join_code,expires_at)").eq("user_id", user.id).maybeSingle();
  if (ex.error) return J({ error: "Database error" }, 500);
  const d: any = (ex.data as any)?.demo_sessions; if (d && new Date(d.expires_at) > new Date()) return J({ code: d.join_code });
  if (await limited(db, ipKey(req, "new"), 20)) return J({ error: "Too many new demo sessions. Try later." }, 429);
  for (let i = 0; i < 3; i++) {
    const code = gen(), { data, error } = await db.from("demo_sessions").insert({ join_code: code }).select("id").single();
    if (error) { if (error.code === "23505") continue; return J({ error: "Could not start session" }, 500); } // retry only on code collision
    const m = await member(data.id);
    if (m.error || !m.data?.length) { await db.from("demo_sessions").delete().eq("id", data.id); return J({ error: "Could not start session" }, 500); }
    return J({ code });
  }
  return J({ error: "Could not start session" }, 500);
}
