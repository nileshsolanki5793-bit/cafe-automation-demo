import { ctx, J } from "@/lib/server";
const one = (x: any) => (Array.isArray(x) ? x[0] : x);
export async function GET(req: Request) {
  const c = await ctx(req); if (c.err) return c.err;
  const { data, error } = await c.db.from("orders").select("*,order_items(*),payments(order_id),feedback(*)").eq("session_id", c.sid).order("created_at", { ascending: false });
  if (error) return J({ error: "Could not load orders" }, 500);
  return J({ orders: data.map((o: any) => { const f = one(o.feedback); return {
    id: o.id, no: o.order_no, key: o.idempotency_key, table: String(o.table_no), sub: o.subtotal, total: o.total, status: o.status, paid: !!one(o.payments),
    items: o.order_items.map((i: any) => ({ name: i.name, opt: i.options, price: i.unit_price, q: i.qty })), fb: f ? { food: f.food, service: f.service, amb: f.ambience } : null }; }) });
}
