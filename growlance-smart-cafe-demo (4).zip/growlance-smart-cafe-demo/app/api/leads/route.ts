import { NextResponse } from "next/server";
import { admin } from "@/lib/supabaseAdmin";
import { ipKey, limited } from "@/lib/server";
import { processQueue } from "@/lib/notify";
export async function POST(req: Request) {
  const db = admin();
  if (!db) return NextResponse.json({ ok: false, error: "Lead storage is not configured." }, { status: 503 });
  let b: any;
  try { b = await req.json(); } catch { return NextResponse.json({ ok: false, error: "Invalid request." }, { status: 400 }); }
  if (b.website) return NextResponse.json({ ok: true }); // honeypot (bots): intentionally not stored
  const cafe = String(b.cafeName ?? "").trim(), city = String(b.city ?? "").trim(), phone = String(b.phone ?? "").replace(/\D/g, "").slice(-10), method = b.contactMethod;
  if (cafe.length < 2 || cafe.length > 80 || city.length < 2 || city.length > 60 || !/^[6-9]\d{9}$/.test(phone) || !["WhatsApp", "Phone call"].includes(method))
    return NextResponse.json({ ok: false, error: "Please check the form fields." }, { status: 422 });
  const key = ipKey(req, "lead");
  if (await limited(db, key, 5)) return NextResponse.json({ ok: false, error: "Too many requests. Try later." }, { status: 429 });
  const { data: id, error } = await db.rpc("create_lead", { p_cafe: cafe, p_city: city, p_phone: phone, p_method: method, p_consent: b.marketingConsent === true, p_ip: key });
  if (error?.code === "23505") return NextResponse.json({ ok: true, duplicate: true }); // identical lead already stored earlier
  if (error || !id) return NextResponse.json({ ok: false, error: "Could not save your request." }, { status: 500 }); // success only after DB commit
  await db.from("events").insert({ name: "lead_submitted" });
  // Lead is safely stored with a queue row. Try to notify now (bounded wait); the scheduled job retries anything that fails.
  await Promise.race([processQueue(db, 3).catch(() => {}), new Promise((r) => setTimeout(r, 6000))]);
  return NextResponse.json({ ok: true });
}
