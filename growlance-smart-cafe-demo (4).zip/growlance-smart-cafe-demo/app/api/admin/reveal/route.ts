import { adminCtx, J } from "@/lib/server";
export async function POST(req: Request) {
  const c = await adminCtx(req, "rev", 30); if (c.err) return c.err;
  const b = await req.json().catch(() => ({})); if (!/^[0-9a-f-]{36}$/.test(b?.id ?? "")) return J({ error: "Invalid id" }, 422);
  const { data } = await c.db.from("leads").select("phone").eq("id", b.id).maybeSingle(); if (!data) return J({ error: "Not found" }, 404);
  await c.db.from("admin_audit").insert({ admin_email: c.user.email, action: "reveal_phone", lead_id: b.id }); // every reveal is logged
  return J({ phone: data.phone });
}
