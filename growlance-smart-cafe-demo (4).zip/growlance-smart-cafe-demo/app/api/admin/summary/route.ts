import { adminCtx, J } from "@/lib/server";
// Admin = a real Supabase Auth user whose confirmed email is in ADMIN_EMAILS. Phones are masked; see /api/admin/reveal.
export async function GET(req: Request) {
  const c = await adminCtx(req, "adm", 60); if (c.err) return c.err;
  const ev = await c.db.from("events").select("name"), counts: Record<string, number> = {};
  (ev.data ?? []).forEach((e: any) => (counts[e.name] = (counts[e.name] ?? 0) + 1));
  const nq = await c.db.from("lead_notifications").select("status"), notify: Record<string, number> = {};
  (nq.data ?? []).forEach((n: any) => (notify[n.status] = (notify[n.status] ?? 0) + 1));
  const l = await c.db.from("leads").select("id,created_at,cafe_name,city,phone,contact_method,marketing_consent").order("created_at", { ascending: false }).limit(200);
  return J({ counts, notify, leads: (l.data ?? []).map((x: any) => ({ ...x, phone: x.phone.slice(0, 2) + "XXXXXX" + x.phone.slice(-2) })) });
}
