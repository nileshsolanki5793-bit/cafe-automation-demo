import { adminCtx, J } from "@/lib/server";
import { processQueue } from "@/lib/notify";
export async function POST(req: Request) {
  const c = await adminCtx(req, "retry", 10); if (c.err) return c.err;
  return J(await processQueue(c.db, 20));
}
