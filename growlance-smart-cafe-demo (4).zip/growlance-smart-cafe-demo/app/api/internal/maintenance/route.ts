import { timingSafeEqual } from "crypto";
import { admin } from "@/lib/supabaseAdmin";
import { J } from "@/lib/server";
import { processQueue } from "@/lib/notify";
// Called every 5 minutes by netlify/functions/maintenance.mts: retries n8n notifications and purges expired demo data.
export async function POST(req: Request) {
  const s = process.env.CRON_SECRET ?? "", g = req.headers.get("x-cron-secret") ?? "", db = admin();
  if (!s || !db) return J({ error: "Not configured" }, 503);
  const a = Buffer.from(g), b = Buffer.from(s); if (a.length !== b.length || !timingSafeEqual(a, b)) return J({ error: "Forbidden" }, 403);
  const purge = await db.rpc("purge_expired_demo_data"); const queue = await processQueue(db, 20);
  return J({ queue, purgeError: purge.error?.message ?? null });
}
