import "./globals.css";
export const metadata = { title: "Growlance Smart Cafe Demo" };
export const viewport = { width: "device-width", initialScale: 1, viewportFit: "cover" };
export default function Root({ children }: { children: React.ReactNode }) {
  return <html lang="en"><body>{children}</body></html>;
}
