-- Anonymous-auth based access (no custom JWT signing). Enable Auth > Sign In / Providers > Anonymous in Supabase.
alter table demo_sessions add column join_code text unique, add column expires_at timestamptz not null default now() + interval '24 hours';
create table session_members(user_id uuid primary key references auth.users on delete cascade, session_id uuid not null references demo_sessions on delete cascade, created_at timestamptz default now());
create table rate_hits(id bigserial primary key, key text not null, created_at timestamptz default now());
create index rate_hits_k on rate_hits(key, created_at);
create table admin_audit(id bigserial primary key, admin_email text, action text, lead_id uuid, created_at timestamptz default now());
alter table session_members enable row level security; alter table rate_hits enable row level security; alter table admin_audit enable row level security;
create function public.is_member(sid uuid) returns boolean language sql security definer stable set search_path = public
 as $$ select exists(select 1 from session_members where user_id = auth.uid() and session_id = sid) $$;
revoke all on function public.is_member(uuid) from public; grant execute on function public.is_member(uuid) to authenticated;
drop policy own_orders on orders; drop policy own_items on order_items; drop policy own_pay on payments; drop policy own_fb on feedback;
create policy m_orders on orders for select to authenticated using (is_member(session_id));
create policy m_items on order_items for select to authenticated using (exists(select 1 from orders o where o.id = order_id and is_member(o.session_id)));
create policy m_pay on payments for select to authenticated using (exists(select 1 from orders o where o.id = order_id and is_member(o.session_id)));
create policy m_fb on feedback for select to authenticated using (exists(select 1 from orders o where o.id = order_id and is_member(o.session_id)));
-- Clients only ever SELECT their own session's rows. All writes, leads, events, audit and rate limits are service-role only.
