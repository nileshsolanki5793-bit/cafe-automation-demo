alter table orders add column order_no int generated always as identity;
