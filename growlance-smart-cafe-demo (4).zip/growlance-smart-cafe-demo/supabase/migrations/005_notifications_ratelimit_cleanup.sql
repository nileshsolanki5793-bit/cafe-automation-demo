-- Persistent n8n notification queue, atomic rate limiting, transactional lead creation, fuller cleanup.
create table lead_notifications(id uuid primary key default gen_random_uuid(), lead_id uuid not null unique references leads on delete cascade,
 status text not null default 'pending' check(status in('pending','sending','sent','failed','dead')), attempts int not null default 0,
 next_attempt_at timestamptz not null default now(), locked_at timestamptz, last_error text, sent_at timestamptz, created_at timestamptz default now());
create index lead_notifications_q on lead_notifications(status, next_attempt_at);
create table lead_notification_log(id bigserial primary key, notification_id uuid not null references lead_notifications on delete cascade,
 attempt int, ok boolean, http_status int, error text, created_at timestamptz default now());
alter table lead_notifications enable row level security; alter table lead_notification_log enable row level security; -- no policies: service role only
-- Lead + queue row are written in ONE transaction, so a saved lead always has a notification record.
create function public.create_lead(p_cafe text, p_city text, p_phone text, p_method text, p_consent boolean, p_ip text) returns uuid
 language plpgsql security definer set search_path = public as $$
 declare v uuid; begin
  insert into leads(cafe_name, city, phone, contact_method, marketing_consent, ip_hash) values (p_cafe, p_city, p_phone, p_method, p_consent, p_ip) returning id into v;
  insert into lead_notifications(lead_id) values (v); return v; end $$;
-- Atomic limiter: returns TRUE when the caller is over the limit. Advisory lock prevents check-then-insert races.
create function public.rate_limit_hit(p_key text, p_max int, p_mins int) returns boolean language plpgsql security definer set search_path = public as $$
 declare c int; begin
  perform pg_advisory_xact_lock(hashtext(p_key));
  select count(*) into c from rate_hits where key = p_key and created_at > now() - make_interval(mins => p_mins);
  if c >= p_max then return true; end if;
  insert into rate_hits(key) values (p_key); return false; end $$;
drop function if exists public.purge_expired_demo_data();
create function public.purge_expired_demo_data() returns void language plpgsql security definer set search_path = public as $$
 begin
  delete from demo_sessions where expires_at < now() - interval '7 days';
  delete from rate_hits where created_at < now() - interval '2 days';
  delete from auth.users where is_anonymous and created_at < now() - interval '7 days';
 end $$;
revoke all on function public.create_lead(text,text,text,text,boolean,text), public.rate_limit_hit(text,int,int), public.purge_expired_demo_data() from public, anon, authenticated;
grant execute on function public.create_lead(text,text,text,text,boolean,text), public.rate_limit_hit(text,int,int), public.purge_expired_demo_data() to service_role;
