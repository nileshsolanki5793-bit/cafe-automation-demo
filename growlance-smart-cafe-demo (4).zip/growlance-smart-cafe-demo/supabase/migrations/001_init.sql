create extension if not exists pgcrypto;
create table demo_sessions(id uuid primary key default gen_random_uuid(), created_at timestamptz default now());
create table orders(id uuid primary key default gen_random_uuid(),
 session_id uuid not null references demo_sessions on delete cascade,
 idempotency_key text not null, table_no int check(table_no between 1 and 20),
 subtotal int not null check(subtotal>=0), total int not null check(total>=0),
 status text not null default 'placed' check(status in('placed','confirmed','preparing','completed')),
 created_at timestamptz default now(), unique(session_id,idempotency_key));
create table order_items(id uuid primary key default gen_random_uuid(),
 order_id uuid not null references orders on delete cascade, name text not null, options text,
 unit_price int not null check(unit_price>=0), qty int not null check(qty between 1 and 9));
create table payments(id uuid primary key default gen_random_uuid(),
 order_id uuid not null unique references orders on delete cascade,
 mode text not null default 'demo' check(mode='demo'), created_at timestamptz default now());
create table feedback(order_id uuid primary key references orders on delete cascade,
 food int check(food between 1 and 5), service int check(service between 1 and 5),
 ambience int check(ambience between 1 and 5), created_at timestamptz default now());
create table leads(id uuid primary key default gen_random_uuid(),
 cafe_name text not null check(char_length(cafe_name) between 2 and 80),
 city text not null check(char_length(city) between 2 and 60),
 phone text not null check(phone ~ '^[6-9][0-9]{9}$'),
 contact_method text not null check(contact_method in('WhatsApp','Phone call')),
 marketing_consent boolean not null default false, ip_hash text, session_id uuid,
 created_at timestamptz default now());
create unique index leads_dedupe on leads(phone, lower(cafe_name));
create table events(id bigserial primary key, session_id uuid, created_at timestamptz default now(),
 name text not null check(name in('landing_visit','demo_started','product_selected','order_placed','order_confirmed','demo_payment_completed','feedback_submitted','lead_form_opened','lead_submitted')));
-- RLS: everything locked by default.
alter table demo_sessions enable row level security; alter table orders enable row level security;
alter table order_items enable row level security; alter table payments enable row level security;
alter table feedback enable row level security; alter table leads enable row level security; alter table events enable row level security;
-- Visitors get READ-ONLY access to their own session via a short-lived server-minted JWT carrying a session_id claim.
-- All writes go through server routes using the service role. leads/events/demo_sessions have no policies (service role only).
create policy own_orders on orders for select to authenticated using(session_id=(auth.jwt()->>'session_id')::uuid);
create policy own_items on order_items for select to authenticated using(exists(select 1 from orders o where o.id=order_id and o.session_id=(auth.jwt()->>'session_id')::uuid));
create policy own_pay on payments for select to authenticated using(exists(select 1 from orders o where o.id=order_id and o.session_id=(auth.jwt()->>'session_id')::uuid));
create policy own_fb on feedback for select to authenticated using(exists(select 1 from orders o where o.id=order_id and o.session_id=(auth.jwt()->>'session_id')::uuid));
alter publication supabase_realtime add table orders, payments, feedback;
