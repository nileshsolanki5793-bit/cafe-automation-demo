-- Session expiry is now enforced in RLS, and client roles lose all table rights except SELECT on their own session's order data.
create or replace function public.is_member(sid uuid) returns boolean language sql security definer stable set search_path = public
 as $$ select exists(select 1 from session_members m join demo_sessions s on s.id = m.session_id
   where m.user_id = auth.uid() and m.session_id = sid and s.expires_at > now()) $$;
revoke all on all tables in schema public from anon, authenticated;
alter default privileges in schema public revoke all on tables from anon, authenticated;
grant select on orders, order_items, payments, feedback to authenticated;
create or replace function public.purge_expired_demo_data() returns void language sql security definer set search_path = public
 as $$ delete from demo_sessions where expires_at < now() - interval '7 days'; delete from rate_hits where created_at < now() - interval '2 days'; $$;
revoke all on function public.purge_expired_demo_data() from public, anon, authenticated;
-- Optional: schedule with pg_cron:  select cron.schedule('purge-demo','0 3 * * *','select public.purge_expired_demo_data()');
