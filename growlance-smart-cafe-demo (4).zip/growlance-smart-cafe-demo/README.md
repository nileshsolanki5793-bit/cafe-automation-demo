# Growlance Smart Cafe Demo: Next.js 16 + Supabase on Netlify
## Honest status (read first)
Written but NEVER installed, built, linted or run. Unverified: `npm install`/`npm run build`, every API route, Supabase Auth/Realtime, two-device sync, the n8n retry job and the Netlify scheduled function. Real photographs are NOT bundled: only labelled placeholder SVGs are in `public/menu/` (no network was available to fetch licensed photos).
## 1. Photos (do before public launch)
Add 8 licensed JPGs named `cappuccino, cold-coffee, masala-chai, club-sandwich, pasta, fries, brownie, cheesecake` (.jpg) to `public/menu/`, about 800x600, under 100 KB each. Keep licence/attribution records. `npm run photos:check` lists missing ones. JPGs override the placeholders automatically.
## 2. Supabase
1. Create a project. SQL Editor: run in order `supabase/migrations/001_init.sql` ... `005_notifications_ratelimit_cleanup.sql`.
2. Authentication > Sign In / Providers: enable **Anonymous sign-ins**; enable CAPTCHA protection before public launch.
3. Authentication > Users: add admin user(s) with email+password and confirm them. Disable public sign-ups if not needed.
4. Confirm Realtime publication `supabase_realtime` includes orders, payments, feedback.
5. Project Settings > API: copy URL, anon/publishable key, service_role/secret key.
## 3. Environment variables (Netlify > Site configuration > Environment variables; set BEFORE the first build)
Public: `NEXT_PUBLIC_SUPABASE_URL`, `NEXT_PUBLIC_SUPABASE_ANON_KEY`, `NEXT_PUBLIC_GOOGLE_REVIEW_URL` (optional).
Server-only secrets: `SUPABASE_SERVICE_ROLE_KEY`, `IP_HASH_SALT` (long random), `ADMIN_EMAILS` (comma-separated), `CRON_SECRET` (long random), `N8N_WEBHOOK_URL`, `N8N_WEBHOOK_SECRET`. Never prefix secrets with NEXT_PUBLIC_.
## 4. Deploy to Netlify
Push to Git > Add new site > Import from Git. Build command `npm run build`, no publish directory, Node 22 (.nvmrc). Do not pin @netlify/plugin-nextjs. Redeploy after any env change.
## 5. Lead notifications (n8n)
A lead and its queue row are saved in one database transaction; the form says success only after that commit. The API tries n8n immediately (6s max). Failures are retried by the scheduled function `netlify/functions/maintenance.mts` every 5 minutes with backoff (up to 8 attempts, then `dead`). Delivery is at-least-once: dedupe in n8n on `lead_id`. Logs: tables `lead_notifications` and `lead_notification_log`; /admin shows counts and a "Retry now" button (fallback if the schedule is not running; scheduled functions may run only on production deploys, so check the Functions tab).
## 6. Cleanup and rate limits
`purge_expired_demo_data()` (run by the same 5-minute job) deletes sessions expired 7+ days, old rate-limit rows and anonymous auth users older than 7 days. Limits are atomic in the database and fail closed.
## 7. Test plan (nothing checked yet)
1. Build passes; banner shows LIVE CONNECTED MODE only after loading. 2. Place an order; rows in `orders`/`order_items`; fake item id returns 422.
3. Two devices: A starts and shows the code; B taps Join with code. Order on A appears on B without refresh; Confirm on B updates A; then Preparing, Completed, payment, feedback.
4. Turn Wi-Fi off and press an action: error toast, no state change. 5. Submit lead: row in `leads` + `lead_notifications`; break N8N_WEBHOOK_URL, confirm status `failed`, fix it, wait 5 min or click Retry now, confirm `sent`.
6. /admin: allow-listed login works, phones masked, Reveal logged in `admin_audit`, other users get 403. 7. Phone at 360px wide.
## 8. Troubleshooting
Banner "Backend unreachable": missing env var / Anonymous sign-ins off. 429: rate limit. 403 admin: email not in ADMIN_EMAILS. Function RPC errors: migration 005 not applied.
